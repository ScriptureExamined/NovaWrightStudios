﻿using System;
using System.Runtime.InteropServices;

namespace NovaWrightFirewallHelper
{

    internal class Program
    {
        private const int DomainProfile = 1;
        private const int PrivateProfile = 2;
        private const int PublicProfile = 4;

        static int Main(string[] args)
        {
            if (args.Length == 0)
            {
                Console.WriteLine("Usage: NovaWrightFirewallHelper <command> [domain,private,public]");
                return 1;
            }

            string command = args[0].ToLowerInvariant();

            try
            {
                return command switch
                {
                    "disable" => DisableAll(),
                    "forceenable" => ForceEnableAll(),
                    "restore" => Restore(args),
                    "set" => SetProfiles(args),
                    "getstate" => GetState(),
                    _ => UnknownCommand(command)
                };
            }
            catch (Exception ex)
            {
                Console.Error.WriteLine("ERROR: " + ex.Message);
                return 2;
            }
        }

        static int SetProfiles(string[] args)
        {
            // set 1,0,1   or   set domain=1 private=0 public=1
            if (args.Length < 2)
            {
                Console.Error.WriteLine("Usage: set domain,private,public  (0 or 1)");
                return 1;
            }

            var parts = args[1].Split(',');
            if (parts.Length != 3)
            {
                Console.Error.WriteLine("Invalid format. Use: set 1,0,1");
                return 1;
            }

            bool domain = parts[0].Trim() == "1";
            bool priv = parts[1].Trim() == "1";
            bool pub = parts[2].Trim() == "1";

            SetProfile(DomainProfile, domain);
            SetProfile(PrivateProfile, priv);
            SetProfile(PublicProfile, pub);

            Console.WriteLine($"Set Domain={domain}, Private={priv}, Public={pub}");
            return 0;
        }

        static int DisableAll()
        {
            SetProfile(DomainProfile, false);
            SetProfile(PrivateProfile, false);
            SetProfile(PublicProfile, false);
            Console.WriteLine("Firewall disabled on all profiles.");
            return 0;
        }

        static int ForceEnableAll()
        {
            SetProfile(DomainProfile, true);
            SetProfile(PrivateProfile, true);
            SetProfile(PublicProfile, true);
            Console.WriteLine("Firewall force-enabled on all profiles.");
            return 0;
        }

        static int Restore(string[] args)
        {
            // Expected: restore 1,0,1   (domain,private,public)
            if (args.Length < 2)
            {
                Console.Error.WriteLine("restore requires state argument, e.g. restore 1,1,0");
                return 1;
            }

            var parts = args[1].Split(',');
            if (parts.Length != 3)
            {
                Console.Error.WriteLine("Invalid state format. Use domain,private,public (0 or 1)");
                return 1;
            }

            bool domain = parts[0].Trim() == "1";
            bool priv = parts[1].Trim() == "1";
            bool pub = parts[2].Trim() == "1";

            SetProfile(DomainProfile, domain);
            SetProfile(PrivateProfile, priv);
            SetProfile(PublicProfile, pub);

            Console.WriteLine($"Firewall restored to Domain={domain}, Private={priv}, Public={pub}");
            return 0;
        }

        static int GetState()
        {
            bool domain = GetProfile(DomainProfile);
            bool priv = GetProfile(PrivateProfile);
            bool pub = GetProfile(PublicProfile);

            Console.WriteLine($"Domain={(domain ? 1 : 0)};Private={(priv ? 1 : 0)};Public={(pub ? 1 : 0)}");
            return 0;
        }

        static int UnknownCommand(string cmd)
        {
            Console.Error.WriteLine($"Unknown command: {cmd}");
            return 1;
        }

        // ─────────────────────────────────────────────
        // COM helpers
        // ─────────────────────────────────────────────

        static dynamic GetPolicy()
        {
            Type type = Type.GetTypeFromProgID("HNetCfg.FwPolicy2")
                ?? throw new InvalidOperationException("Could not get HNetCfg.FwPolicy2");
            return Activator.CreateInstance(type)
                ?? throw new InvalidOperationException("Could not create FwPolicy2 instance");
        }

        static bool GetProfile(int profile)
        {
            dynamic policy = GetPolicy();
            return (bool)policy.FirewallEnabled[profile];
        }

        static void SetProfile(int profile, bool enabled)
        {
            dynamic policy = GetPolicy();
            policy.FirewallEnabled[profile] = enabled;
        }
    }
}