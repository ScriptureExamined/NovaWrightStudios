using Microsoft.UI.Xaml;
using NovaWrightFirewallTray.Models;
using NovaWrightFirewallTray.Services;
using static NovaWrightFirewallTray.Services.SettingsService;

namespace NovaWrightFirewallTray
{
    public sealed partial class SettingsWindow : Window
    {
        public AppSettings ViewModel { get; }

        private readonly SettingsService _settingsService;

        public SettingsWindow(SettingsService settingsService)
        {
            this.InitializeComponent();
            _settingsService = settingsService;

            // Work on a copy so Cancel works
            ViewModel = new AppSettings
            {
                DefaultDisableMinutes = settingsService.Settings.DefaultDisableMinutes,
                EnableSounds = settingsService.Settings.EnableSounds,
                StartWithWindows = settingsService.Settings.StartWithWindows,
                Show5MinuteWarning = settingsService.Settings.Show5MinuteWarning,
                Show1MinuteWarning = settingsService.Settings.Show1MinuteWarning,
                Show30SecondWarning = settingsService.Settings.Show30SecondWarning,
                ConfirmLongDurations = settingsService.Settings.ConfirmLongDurations,
                LongDurationThresholdMinutes = settingsService.Settings.LongDurationThresholdMinutes,
                // In the ViewModel copy section (constructor)
                CustomWavPath = settingsService.Settings.CustomWavPath,
            };
        }

        private async void Save_Click(object sender, RoutedEventArgs e)
        {
            var s = _settingsService.Settings;

            s.DefaultDisableMinutes = ViewModel.DefaultDisableMinutes;
            s.EnableSounds = ViewModel.EnableSounds;
            s.StartWithWindows = ViewModel.StartWithWindows;
            s.Show5MinuteWarning = ViewModel.Show5MinuteWarning;
            s.Show1MinuteWarning = ViewModel.Show1MinuteWarning;
            s.Show30SecondWarning = ViewModel.Show30SecondWarning;
            s.ConfirmLongDurations = ViewModel.ConfirmLongDurations;
            s.LongDurationThresholdMinutes = ViewModel.LongDurationThresholdMinutes;
            s.CustomWavPath = ViewModel.CustomWavPath;          // ← new line

            _settingsService.Save();

            // Apply the sound settings immediately
            App.NotificationService.EnableSound = s.EnableSounds;
            App.NotificationService.CustomWavPath = s.CustomWavPath;

            // Apply Start with Windows
            await StartupService.SetEnabledAsync(s.StartWithWindows);

            this.Close();
        }


        private void Cancel_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }

        

// Browse button
private async void BrowseWav_Click(object sender, RoutedEventArgs e)
        {
            var picker = new Windows.Storage.Pickers.FileOpenPicker();
            picker.FileTypeFilter.Add(".wav");

            // Needed for WinUI 3
            var hwnd = WinRT.Interop.WindowNative.GetWindowHandle(this);
            WinRT.Interop.InitializeWithWindow.Initialize(picker, hwnd);

            var file = await picker.PickSingleFileAsync();
            if (file != null)
            {
                ViewModel.CustomWavPath = file.Path;
            }
        }
    }
}