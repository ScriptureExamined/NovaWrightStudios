﻿using System;
using Microsoft.UI.Xaml;
using NovaWrightFirewallTray.Services;

namespace NovaWrightFirewallTray
{
    public sealed partial class DiagnosticsWindow : Window
    {
        private readonly DispatcherTimer _timer;

        public DiagnosticsWindow()
        {
            this.InitializeComponent();

            HistoryList.ItemsSource = App.HistoryService.Entries;

            _timer = new DispatcherTimer { Interval = TimeSpan.FromSeconds(1) };
            _timer.Tick += (s, e) => Refresh();
            _timer.Start();

            Refresh();
        }

        private void Refresh()
        {
            var state = App.FirewallService.GetCurrentState();

            DomainText.Text = $"Domain: {(state.Domain ? "On" : "Off")}";
            PrivateText.Text = $"Private: {(state.Private ? "On" : "Off")}";
            PublicText.Text = $"Public: {(state.Public ? "On" : "Off")}";

            try
            {
                NetworkCategoryText.Text =
                    "Active network: " + App.NetworkProfileService.GetActiveCategoryDisplay();
            }
            catch
            {
                NetworkCategoryText.Text = "Active network: —";
            }

            if (App.TimerService.IsRunning || App.TimerService.IsPaused)
            {
                var remaining = App.TimerService.Remaining;
                string timeText = remaining.TotalHours >= 1
                    ? remaining.ToString(@"h\:mm\:ss")
                    : remaining.ToString(@"mm\:ss");
                string status = App.TimerService.IsPaused ? "PAUSED" : "RUNNING";
                TimerText.Text = $"Timer: {status} — {timeText} remaining";
            }
            else
            {
                TimerText.Text = "Timer: not running";
            }

            var saved = App.FirewallService.GetSavedState();
            SavedStateText.Text = saved != null
                ? $"Saved pre-disable state: {saved}"
                : "Saved pre-disable state: (none)";

            try
            {
                var stats = App.FirewallService.GetRuleStats();
                RulesTotalText.Text = $"Total: {stats.Total}";
                RulesEnabledText.Text = $"Enabled: {stats.Enabled}";
                RulesDisabledText.Text = $"Disabled: {stats.Disabled}";
                RulesDirectionText.Text = $"Inbound: {stats.Inbound}  /  Outbound: {stats.Outbound}";
            }
            catch (Exception ex)
            {
                RulesTotalText.Text = "Total: (error)";
                RulesEnabledText.Text = ex.Message;
                RulesDisabledText.Text = "";
                RulesDirectionText.Text = "";
            }

            HelperPathText.Text = "Helper: elevated NovaWrightFirewallHelper.exe";
        }

        private void Refresh_Click(object sender, RoutedEventArgs e) => Refresh();

        private void Close_Click(object sender, RoutedEventArgs e) => this.Close();
    }
}