﻿namespace NovaWrightFirewallTray.Models
{
    public class AppSettings
    {
        public int DefaultDisableMinutes { get; set; } = 10;
        public bool EnableSounds { get; set; } = true;
        public bool StartWithWindows { get; set; } = false;
        public bool Show5MinuteWarning { get; set; } = true;
        public bool Show1MinuteWarning { get; set; } = true;
        public bool Show30SecondWarning { get; set; } = true;
        public bool ConfirmLongDurations { get; set; } = true;
        public int LongDurationThresholdMinutes { get; set; } = 60;
        public int LastUsedDisableMinutes { get; set; } = 10;
        public string CustomWavPath { get; set; } = "";
        
    }
}
