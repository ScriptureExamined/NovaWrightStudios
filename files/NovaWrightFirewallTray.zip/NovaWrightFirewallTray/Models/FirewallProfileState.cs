﻿namespace NovaWrightFirewallTray.Models
{
    public class FirewallProfileState
    {
        public bool Domain { get; set; }
        public bool Private { get; set; }
        public bool Public { get; set; }
        public DateTime CapturedAt { get; set; } = DateTime.Now;

        public bool IsAnyDisabled => !Domain || !Private || !Public;

        public bool IsFullyEnabled => Domain && Private && Public;

        public override string ToString()
        {
            return $"Domain: {(Domain ? "On" : "Off")}, " +
                   $"Private: {(Private ? "On" : "Off")}, " +
                   $"Public: {(Public ? "On" : "Off")}";
        }
    }
}