﻿namespace NovaWrightFirewallTray.Models
{
    public class HistoryEntry
    {
        public DateTime Timestamp { get; set; } = DateTime.Now;
        public string Action { get; set; } = "";          // Disable, Restore, ForceEnable, AutoRestore, ExternalChange
        public string Details { get; set; } = "";
        public string PreviousState { get; set; } = "";
        public string NewState { get; set; } = "";
    }
}