using Microsoft.UI.Xaml;
using Microsoft.UI.Xaml.Controls;
using Microsoft.UI.Xaml.Media;
using NovaWrightFirewallTray.Models;
using NovaWrightFirewallTray.Services;
using System;
using System.Threading.Tasks;
using Windows.UI;

namespace NovaWrightFirewallTray
{
    public sealed partial class MainWindow : Window
    {
        private readonly DispatcherTimer _uiTimer;

        public MainWindow()
        {
            this.InitializeComponent();

            // Bind history
            HistoryList.ItemsSource = App.HistoryService.Entries;

            // Intercept the close button (X)
            this.AppWindow.Closing += AppWindow_Closing;

            // Update UI every second
            _uiTimer = new DispatcherTimer { Interval = TimeSpan.FromSeconds(1) };
            _uiTimer.Tick += (s, e) => RefreshUI();
            _uiTimer.Start();

            // Per-profile timers (live toggles)
            App.ProfileTimerService.Tick += (s, e) => RefreshUI();

            RefreshUI();
        }

        private void RefreshUI()
        {
            var state = App.FirewallService.GetCurrentState();

            // Status pills
            UpdatePill(DomainStatusPill, DomainStatus, state.Domain);
            UpdatePill(PrivateStatusPill, PrivateStatus, state.Private);
            UpdatePill(PublicStatusPill, PublicStatus, state.Public);

            // Card tint
            DomainCard.Background = state.Domain ? GreenBrush() : RedBrush();
            PrivateCard.Background = state.Private ? GreenBrush() : RedBrush();
            PublicCard.Background = state.Public ? GreenBrush() : RedBrush();

            // Per-profile timers
            DomainTimer.Text = FormatProfileTimer(FirewallProfileKind.Domain);
            PrivateTimer.Text = FormatProfileTimer(FirewallProfileKind.Private);
            PublicTimer.Text = FormatProfileTimer(FirewallProfileKind.Public);

            // Toggle buttons (label + icon)
            UpdateToggle(DomainToggleLabel, DomainToggleIcon, state.Domain);
            UpdateToggle(PrivateToggleLabel, PrivateToggleIcon, state.Private);
            UpdateToggle(PublicToggleLabel, PublicToggleIcon, state.Public);

            NetworkCategoryText.Text =
                "Active network: " + App.NetworkProfileService.GetActiveCategoryDisplay();

            // Global timer + progress
            if (App.TimerService.IsRunning || App.TimerService.IsPaused)
            {
                var remaining = App.TimerService.Remaining;
                string timeText = remaining.TotalHours >= 1
                    ? remaining.ToString(@"h\:mm\:ss")
                    : remaining.ToString(@"mm\:ss");
                string status = App.TimerService.IsPaused ? "PAUSED" : "DISABLED";

                StatusTitle.Text = $"Firewall {status}";
                TimerText.Text = timeText;
                StatusSubtitle.Text = state.ToString();

                TimerProgressBar.Visibility = Visibility.Visible;

                double totalMinutes = Math.Max(1, App.SettingsService.Settings.LastUsedDisableMinutes > 0
                    ? App.SettingsService.Settings.LastUsedDisableMinutes
                    : App.SettingsService.Settings.DefaultDisableMinutes);
                double remainingMinutes = remaining.TotalMinutes;
                double pct = Math.Max(0, Math.Min(1, remainingMinutes / totalMinutes));

                // Red width = remaining portion; green shows through the rest
                double fullWidth = TimerProgressBar.ActualWidth;
                if (fullWidth <= 0) fullWidth = 160; // fallback before first layout
                TimerProgressFill.Width = fullWidth * pct;
            }
            else if (state.IsFullyEnabled)
            {
                StatusTitle.Text = "Firewall ENABLED";
                TimerText.Text = "";
                StatusSubtitle.Text = "";
                TimerProgressBar.Visibility = Visibility.Collapsed;
                TimerProgressFill.Width = 0;
            }
            else
            {
                StatusTitle.Text = "Firewall PARTIALLY DISABLED";
                TimerText.Text = "";
                StatusSubtitle.Text = state.ToString();
                TimerProgressBar.Visibility = Visibility.Collapsed;
                TimerProgressFill.Width = 0;
            }
        }

        private static void UpdatePill(Border pill, TextBlock label, bool isOn)
        {
            label.Text = isOn ? "On" : "Off";
            pill.Background = isOn
                ? new SolidColorBrush(Color.FromArgb(0x40, 0x00, 0xB4, 0x00))
                : new SolidColorBrush(Color.FromArgb(0x40, 0xC8, 0x00, 0x00));
        }

        private static void UpdateToggle(TextBlock label, FontIcon icon, bool isOn)
        {
            if (isOn)
            {
                label.Text = "Turn off";
                icon.Glyph = "\uE71A";   // Disable / Block
            }
            else
            {
                label.Text = "Turn on";
                icon.Glyph = "\uE8FB";   // Accept / Check
            }
        }

        private static string FormatProfileTimer(FirewallProfileKind profile)
        {
            if (!App.ProfileTimerService.IsRunning(profile))
                return "";

            var r = App.ProfileTimerService.Remaining(profile);
            string t = r.TotalHours >= 1 ? r.ToString(@"h\:mm\:ss") : r.ToString(@"mm\:ss");
            return $"{t} left";
        }

        private async void AppWindow_Closing(Microsoft.UI.Windowing.AppWindow sender, Microsoft.UI.Windowing.AppWindowClosingEventArgs args)
        {
            // Always cancel the real close
            args.Cancel = true;

            var dialog = new ContentDialog
            {
                Title = "NovaWright Firewall Monitor",
                Content = "Do you want to leave the program running in the system tray?",
                PrimaryButtonText = "Yes, keep running in tray",
                SecondaryButtonText = "No, exit completely",
                DefaultButton = ContentDialogButton.Primary,
                XamlRoot = this.Content.XamlRoot
            };

            var result = await dialog.ShowAsync();

            if (result == ContentDialogResult.Primary)
            {
                // Just hide the window
                this.AppWindow.Hide();
            }
            else
            {
                // Full exit
                if (Application.Current is App app)
                    app.ShutdownApp();
            }
        }

        private async void Domain_Click(object sender, RoutedEventArgs e) =>
            await ToggleProfileAsync(FirewallProfileKind.Domain);

        private async void Private_Click(object sender, RoutedEventArgs e) =>
            await ToggleProfileAsync(FirewallProfileKind.Private);

        private async void Public_Click(object sender, RoutedEventArgs e) =>
            await ToggleProfileAsync(FirewallProfileKind.Public);

        private async Task ToggleProfileAsync(FirewallProfileKind profile)
        {
            try
            {
                var state = App.FirewallService.GetCurrentState();
                bool current = profile switch
                {
                    FirewallProfileKind.Domain => state.Domain,
                    FirewallProfileKind.Private => state.Private,
                    FirewallProfileKind.Public => state.Public,
                    _ => true
                };

                bool domain = state.Domain, priv = state.Private, pub = state.Public;

                if (current)
                {
                    // Turn OFF → start per-profile timer
                    int minutes = App.SettingsService.Settings.DefaultDisableMinutes;

                    if (Application.Current is App application)
                    {
                        if (!await application.ConfirmLongDurationIfNeededAsync(minutes))
                            return;
                    }

                    switch (profile)
                    {
                        case FirewallProfileKind.Domain: domain = false; break;
                        case FirewallProfileKind.Private: priv = false; break;
                        case FirewallProfileKind.Public: pub = false; break;
                    }

                    await App.FirewallService.SetProfilesAsync(domain, priv, pub);
                    App.ProfileTimerService.Start(profile, previousEnabled: true, TimeSpan.FromMinutes(minutes));

                    App.HistoryService.Add("Disable",
                        $"{profile} off for {minutes} min",
                        state.ToString(),
                        App.FirewallService.GetCurrentState().ToString());
                }
                else
                {
                    // Turn ON → stop that profile's timer
                    switch (profile)
                    {
                        case FirewallProfileKind.Domain: domain = true; break;
                        case FirewallProfileKind.Private: priv = true; break;
                        case FirewallProfileKind.Public: pub = true; break;
                    }

                    await App.FirewallService.SetProfilesAsync(domain, priv, pub);
                    App.ProfileTimerService.Stop(profile);
                    App.ProfileTimerService.ClearSaved(profile);

                    App.HistoryService.Add("Enable",
                        $"{profile} turned on",
                        state.ToString(),
                        App.FirewallService.GetCurrentState().ToString());
                }

                if (Application.Current is App app)
                    app.RefreshTrayTooltip();

                if (profile == FirewallProfileKind.Public &&
                    App.NetworkProfileService.GetActiveCategory() == NetworkCategory.Public)
                {
                    var dialog = new ContentDialog
                    {
                        Title = "Public network warning",
                        Content = "You appear to be on a Public network.\n\nTurning the Public firewall profile off reduces protection on this network.\n\nContinue?",
                        PrimaryButtonText = "Turn off anyway",
                        CloseButtonText = "Cancel",
                        DefaultButton = ContentDialogButton.Close,
                        XamlRoot = this.Content.XamlRoot
                    };

                    var result = await dialog.ShowAsync();
                    if (result != ContentDialogResult.Primary)
                        return;
                }

                RefreshUI();
            }
            catch (Exception ex)
            {
                System.Diagnostics.Debug.WriteLine(ex.Message);
            }
        }

        private async void Disable_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                int minutes = App.SettingsService.Settings.DefaultDisableMinutes;

                if (App.SettingsService.Settings.ConfirmLongDurations &&
                    minutes >= App.SettingsService.Settings.LongDurationThresholdMinutes)
                {
                    var dialog = new ContentDialog
                    {
                        Title = "Confirm long disable",
                        Content = $"You are about to disable the firewall for {minutes} minutes.\n\nContinue?",
                        PrimaryButtonText = "Yes, disable",
                        CloseButtonText = "Cancel",
                        DefaultButton = ContentDialogButton.Close,
                        XamlRoot = this.Content.XamlRoot
                    };

                    var result = await dialog.ShowAsync();
                    if (result != ContentDialogResult.Primary)
                        return;
                }

                var previous = App.FirewallService.GetCurrentState().ToString();
                App.FirewallService.SavePreDisableState();
                await App.FirewallService.DisableProfilesAsync();
                App.TimerService.Start(TimeSpan.FromMinutes(minutes));

                App.HistoryService.Add("Disable",
                    $"Main window – disabled for {minutes} minutes",
                    previous,
                    App.FirewallService.GetCurrentState().ToString());

                App.NotificationService.ShowFirewallDisabled(minutes);
                RefreshUI();
            }
            catch (Exception ex)
            {
                System.Diagnostics.Debug.WriteLine(ex.Message);
            }
        }

        private async void CustomDuration_Click(object sender, RoutedEventArgs e)
        {
            if (Application.Current is App app)
                await app.RunCustomDurationAsync();

            RefreshUI();
        }

        private async void DisableUntil_Click(object sender, RoutedEventArgs e)
        {
            if (Application.Current is App app)
                await app.RunDisableUntilAsync();
            RefreshUI();
        }

        private async void Restore_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                var previous = App.FirewallService.GetCurrentState().ToString();
                App.TimerService.Stop();
                await App.FirewallService.RestorePreviousStateAsync();

                App.HistoryService.Add("Restore", "Manual restore", previous, App.FirewallService.GetCurrentState().ToString());
                App.NotificationService.ShowFirewallRestored();
                RefreshUI();
            }
            catch (Exception ex)
            {
                System.Diagnostics.Debug.WriteLine(ex.Message);
            }
        }

        private async void Emergency_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                var previous = App.FirewallService.GetCurrentState().ToString();
                App.TimerService.Stop();
                await App.FirewallService.ForceEnableAllAsync();

                App.HistoryService.Add("ForceEnable", "Emergency enable all profiles", previous, App.FirewallService.GetCurrentState().ToString());
                App.NotificationService.ShowFirewallRestored();
                RefreshUI();
            }
            catch (Exception ex)
            {
                System.Diagnostics.Debug.WriteLine(ex.Message);
            }
        }

        private void Settings_Click(object sender, RoutedEventArgs e)
        {
            var settingsWindow = new SettingsWindow(App.SettingsService);
            settingsWindow.Activate();
        }

        private void Diagnostics_Click(object sender, RoutedEventArgs e)
        {
            var win = new DiagnosticsWindow();
            win.Activate();
        }

        private void Help_Click(object sender, RoutedEventArgs e) => new HelpWindow().Activate();
        private void About_Click(object sender, RoutedEventArgs e) => new AboutWindow().Activate();

        private static SolidColorBrush GreenBrush() =>
            new SolidColorBrush(Color.FromArgb(40, 0, 180, 0));

        private static SolidColorBrush RedBrush() =>
            new SolidColorBrush(Color.FromArgb(40, 200, 0, 0));

        /// <summary>
        /// pct = 100 → red(just disabled), pct = 0 → green(about to restore)
        /// </summary>
        //private static SolidColorBrush ProgressBrush(double pct)
        //{
        //    byte r = (byte)(200 * (pct / 100.0));
        //    byte g = (byte)(180 * (1.0 - pct / 100.0));
        //    byte b = 0;
        //    return new SolidColorBrush(Color.FromArgb(255, r, g, b));
        //}
    }
}