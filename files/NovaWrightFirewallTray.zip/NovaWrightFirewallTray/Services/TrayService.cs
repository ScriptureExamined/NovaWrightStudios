﻿using Microsoft.UI.Xaml;
using System.Diagnostics;
using System.Runtime.InteropServices;
using WinRT.Interop;

namespace NovaWrightFirewallTray.Services
{
    public class TrayService : IDisposable
    {
        private const int WM_TRAYICON = 0x8000;
        private const int WM_LBUTTONUP = 0x0202;
        private const int WM_RBUTTONUP = 0x0205;

        private const int NIF_MESSAGE = 0x00000001;
        private const int NIF_ICON = 0x00000002;
        private const int NIF_TIP = 0x00000004;

        private const int NIM_ADD = 0x00000000;
        private const int NIM_MODIFY = 0x00000001;
        private const int NIM_DELETE = 0x00000002;

        private const uint MF_STRING = 0x00000000;
        private const uint MF_SEPARATOR = 0x00000800;
        private const uint MF_POPUP = 0x00000010;
        private const uint TPM_RETURNCMD = 0x0100;
        private const uint TPM_RIGHTBUTTON = 0x0002;

        // Menu command IDs
        private const int ID_DISABLE_5 = 1001;
        private const int ID_DISABLE_15 = 1002;
        private const int ID_DISABLE_30 = 1003;
        private const int ID_DISABLE_60 = 1004;
        private const int ID_CUSTOM = 1005;
        private const int ID_UNTIL = 1006;
        private const int ID_ADD5 = 1010;
        private const int ID_SUB5 = 1011;
        private const int ID_PAUSE = 1020;
        private const int ID_RESUME = 1021;
        private const int ID_EMERGENCY = 1030;
        private const int ID_OPEN_MAIN = 1040;
        private const int ID_SETTINGS = 1041;
        private const int ID_DIAGNOSTICS = 1042;
        private const int ID_HELP = 1043;
        private const int ID_ABOUT = 1044;
        private const int ID_EXIT = 1050;

        private IntPtr _hwnd;
        private IntPtr _hIconOn;
        private IntPtr _hIconPartial;
        private IntPtr _hIconOff;
        private bool _added;
        private NOTIFYICONDATA _data;
        private IntPtr _oldWndProc;
        private WndProcDelegate? _wndProcDelegate;

        private readonly FirewallService _firewallService;
        private readonly TimerService _timerService;
        private readonly SettingsService _settingsService;

        public event EventHandler? LeftClicked;
        public event EventHandler? OpenMainWindowRequested;
        public event EventHandler? OpenSettingsRequested;
        public event EventHandler? OpenDiagnosticsRequested;
        public event EventHandler? ExitRequested;
        public event EventHandler<int>? DisableRequested;
        public event EventHandler? EmergencyRestoreRequested;
        public event EventHandler? Add5Requested;
        public event EventHandler? Subtract5Requested;
        public event EventHandler? CustomDurationRequested;
        public event EventHandler? DisableUntilRequested;
        public event EventHandler? HelpRequested;
        public event EventHandler? AboutRequested;

        public TrayService(
            FirewallService firewallService,
            TimerService timerService,
            SettingsService settingsService)
        {
            _firewallService = firewallService;
            _timerService = timerService;
            _settingsService = settingsService;
        }

        public void Initialize(Window window)
        {
            _hwnd = WindowNative.GetWindowHandle(window);

            _wndProcDelegate = CustomWndProc;
            _oldWndProc = SetWindowLongPtr(_hwnd, -4, Marshal.GetFunctionPointerForDelegate(_wndProcDelegate));

            _hIconOn = LoadIconFromAssets("Firewall.ico");
            _hIconPartial = LoadIconFromAssets("FirewallPartial.ico");
            _hIconOff = LoadIconFromAssets("FirewallOff.ico");

            if (_hIconOn == IntPtr.Zero)
                _hIconOn = LoadIcon(IntPtr.Zero, (IntPtr)32518); // IDI_SHIELD

            if (_hIconPartial == IntPtr.Zero)
                _hIconPartial = _hIconOn;
            if (_hIconOff == IntPtr.Zero)
                _hIconOff = _hIconOn;

            _data = new NOTIFYICONDATA
            {
                cbSize = (uint)Marshal.SizeOf<NOTIFYICONDATA>(),
                hWnd = _hwnd,
                uID = 1,
                uFlags = NIF_MESSAGE | NIF_ICON | NIF_TIP,
                uCallbackMessage = WM_TRAYICON,
                hIcon = _hIconOn,
                szTip = "NovaWright Firewall Monitor"
            };

            Shell_NotifyIcon(NIM_ADD, ref _data);
            _added = true;

            _timerService.Tick += (s, e) => UpdateTrayAppearance();
            _timerService.Expired += (s, e) => UpdateTrayAppearance();
            UpdateTrayAppearance();
        }

        public void UpdateTrayAppearance()
        {
            if (!_added) return;

            var state = _firewallService.GetCurrentState();

            // Icon by state
            if (!state.Domain && !state.Private && !state.Public)
                _data.hIcon = _hIconOff != IntPtr.Zero ? _hIconOff : _hIconOn;
            else if (state.IsFullyEnabled)
                _data.hIcon = _hIconOn;
            else
                _data.hIcon = _hIconPartial != IntPtr.Zero ? _hIconPartial : _hIconOn;

            // Tooltip
            string tip;

            TimeSpan soonest = TimeSpan.MaxValue;
            bool anyProfileTimer = false;

            if (App.ProfileTimerService != null)
            {
                foreach (FirewallProfileKind p in new[]
                {
                    FirewallProfileKind.Domain,
                    FirewallProfileKind.Private,
                    FirewallProfileKind.Public
                })
                {
                    if (App.ProfileTimerService.IsRunning(p))
                    {
                        anyProfileTimer = true;
                        var r = App.ProfileTimerService.Remaining(p);
                        if (r < soonest)
                            soonest = r;
                    }
                }
            }

            if (_timerService.IsRunning || _timerService.IsPaused)
            {
                var remaining = _timerService.Remaining;
                string timeText = remaining.TotalHours >= 1
                    ? remaining.ToString(@"h\:mm\:ss")
                    : remaining.ToString(@"mm\:ss");
                string status = _timerService.IsPaused ? "PAUSED" : "DISABLED";
                tip = $"Firewall: {status}  {timeText} left";
            }
            else if (anyProfileTimer)
            {
                string timeText = soonest.TotalHours >= 1
                    ? soonest.ToString(@"h\:mm\:ss")
                    : soonest.ToString(@"mm\:ss");
                tip = state.IsFullyEnabled
                    ? $"Firewall: ENABLED  ({timeText})"
                    : $"Firewall: PARTIAL  {timeText} left";
            }
            else if (state.IsFullyEnabled)
            {
                tip = "Firewall: ENABLED";
            }
            else
            {
                tip = "Firewall: PARTIALLY DISABLED";
            }

            if (tip.Length > 127)
                tip = tip.Substring(0, 127);

            _data.szTip = tip;
            _data.uFlags = NIF_ICON | NIF_TIP;
            Shell_NotifyIcon(NIM_MODIFY, ref _data);
        }

        public void Dispose()
        {
            if (_added)
            {
                Shell_NotifyIcon(NIM_DELETE, ref _data);
                _added = false;
            }

            if (_hIconOff != IntPtr.Zero && _hIconOff != _hIconOn)
                DestroyIcon(_hIconOff);
            if (_hIconPartial != IntPtr.Zero && _hIconPartial != _hIconOn)
                DestroyIcon(_hIconPartial);
            if (_hIconOn != IntPtr.Zero)
                DestroyIcon(_hIconOn);

            _hIconOn = IntPtr.Zero;
            _hIconPartial = IntPtr.Zero;
            _hIconOff = IntPtr.Zero;

            if (_oldWndProc != IntPtr.Zero && _hwnd != IntPtr.Zero)
            {
                SetWindowLongPtr(_hwnd, -4, _oldWndProc);
                _oldWndProc = IntPtr.Zero;
            }
        }

        private IntPtr LoadIconFromAssets(string fileName)
        {
            string path = System.IO.Path.Combine(AppContext.BaseDirectory, "Assets", fileName);
            if (!System.IO.File.Exists(path))
            {
                Debug.WriteLine("Tray icon missing: " + path);
                return IntPtr.Zero;
            }

            return LoadImage(IntPtr.Zero, path, 1 /*IMAGE_ICON*/, 0, 0, 0x00000010 /*LR_LOADFROMFILE*/);
        }

        private void ShowNativeContextMenu()
        {
            IntPtr hMenu = CreatePopupMenu();
            IntPtr hDisable = CreatePopupMenu();

            AppendMenu(hDisable, MF_STRING, ID_DISABLE_5, "5 Minutes");
            AppendMenu(hDisable, MF_STRING, ID_DISABLE_15, "15 Minutes");
            AppendMenu(hDisable, MF_STRING, ID_DISABLE_30, "30 Minutes");
            AppendMenu(hDisable, MF_STRING, ID_DISABLE_60, "1 Hour");
            AppendMenu(hDisable, MF_SEPARATOR, 0, null!);
            AppendMenu(hDisable, MF_STRING, ID_CUSTOM, "Custom duration...");
            AppendMenu(hDisable, MF_STRING, ID_UNTIL, "Disable until...");
            AppendMenu(hMenu, MF_POPUP, (uint)hDisable.ToInt64(), "Disable for...");

            AppendMenu(hMenu, MF_STRING, ID_ADD5, "Add 5 Minutes");
            AppendMenu(hMenu, MF_STRING, ID_SUB5, "Subtract 5 Minutes");

            AppendMenu(hMenu, MF_STRING, ID_HELP, "Help...");
            AppendMenu(hMenu, MF_STRING, ID_ABOUT, "About...");

            if (_timerService.IsRunning || _timerService.IsPaused)
            {
                AppendMenu(hMenu, MF_SEPARATOR, 0, null!);
                if (_timerService.IsPaused)
                    AppendMenu(hMenu, MF_STRING, ID_RESUME, "Resume Timer");
                else
                    AppendMenu(hMenu, MF_STRING, ID_PAUSE, "Pause Timer");
            }

            AppendMenu(hMenu, MF_SEPARATOR, 0, null!);
            AppendMenu(hMenu, MF_STRING, ID_EMERGENCY, "Restore Firewall (Emergency)");
            AppendMenu(hMenu, MF_SEPARATOR, 0, null!);
            AppendMenu(hMenu, MF_STRING, ID_OPEN_MAIN, "Open Main Window");
            AppendMenu(hMenu, MF_STRING, ID_SETTINGS, "Settings...");
            AppendMenu(hMenu, MF_STRING, ID_DIAGNOSTICS, "Diagnostics...");
            AppendMenu(hMenu, MF_SEPARATOR, 0, null!);
            AppendMenu(hMenu, MF_STRING, ID_EXIT, "Exit");

            GetCursorPos(out POINT pt);
            SetForegroundWindow(_hwnd);

            uint cmd = TrackPopupMenu(hMenu, TPM_RETURNCMD | TPM_RIGHTBUTTON, pt.X, pt.Y, 0, _hwnd, IntPtr.Zero);

            DestroyMenu(hDisable);
            DestroyMenu(hMenu);

            switch (cmd)
            {
                case ID_DISABLE_5: DisableRequested?.Invoke(this, 5); break;
                case ID_DISABLE_15: DisableRequested?.Invoke(this, 15); break;
                case ID_DISABLE_30: DisableRequested?.Invoke(this, 30); break;
                case ID_DISABLE_60: DisableRequested?.Invoke(this, 60); break;
                case ID_CUSTOM: CustomDurationRequested?.Invoke(this, EventArgs.Empty); break;
                case ID_UNTIL: DisableUntilRequested?.Invoke(this, EventArgs.Empty); break;
                case ID_ADD5: Add5Requested?.Invoke(this, EventArgs.Empty); break;
                case ID_SUB5: Subtract5Requested?.Invoke(this, EventArgs.Empty); break;
                case ID_PAUSE: _timerService.Pause(); UpdateTrayAppearance(); break;
                case ID_RESUME: _timerService.Resume(); UpdateTrayAppearance(); break;
                case ID_EMERGENCY: EmergencyRestoreRequested?.Invoke(this, EventArgs.Empty); break;
                case ID_OPEN_MAIN: OpenMainWindowRequested?.Invoke(this, EventArgs.Empty); break;
                case ID_SETTINGS: OpenSettingsRequested?.Invoke(this, EventArgs.Empty); break;
                case ID_DIAGNOSTICS: OpenDiagnosticsRequested?.Invoke(this, EventArgs.Empty); break;
                case ID_EXIT: ExitRequested?.Invoke(this, EventArgs.Empty); break;
                case ID_HELP: HelpRequested?.Invoke(this, EventArgs.Empty); break;
                case ID_ABOUT: AboutRequested?.Invoke(this, EventArgs.Empty); break;
            }
        }

        private IntPtr CustomWndProc(IntPtr hWnd, uint msg, IntPtr wParam, IntPtr lParam)
        {
            if (msg == WM_TRAYICON)
            {
                int mouseMsg = lParam.ToInt32();

                if (mouseMsg == WM_LBUTTONUP)
                {
                    LeftClicked?.Invoke(this, EventArgs.Empty);
                    return IntPtr.Zero;
                }

                if (mouseMsg == WM_RBUTTONUP)
                {
                    ShowNativeContextMenu();
                    return IntPtr.Zero;
                }
            }

            return CallWindowProc(_oldWndProc, hWnd, msg, wParam, lParam);
        }

        // ─────────────────────────────────────────────
        // Win32
        // ─────────────────────────────────────────────

        [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Unicode)]
        private struct NOTIFYICONDATA
        {
            public uint cbSize;
            public IntPtr hWnd;
            public uint uID;
            public uint uFlags;
            public uint uCallbackMessage;
            public IntPtr hIcon;
            [MarshalAs(UnmanagedType.ByValTStr, SizeConst = 128)]
            public string szTip;
        }

        [StructLayout(LayoutKind.Sequential)]
        private struct POINT
        {
            public int X;
            public int Y;
        }

        private delegate IntPtr WndProcDelegate(IntPtr hWnd, uint msg, IntPtr wParam, IntPtr lParam);

        [DllImport("shell32.dll", CharSet = CharSet.Unicode)]
        private static extern bool Shell_NotifyIcon(uint dwMessage, ref NOTIFYICONDATA lpData);

        [DllImport("user32.dll", CharSet = CharSet.Unicode)]
        private static extern IntPtr LoadIcon(IntPtr hInstance, IntPtr lpIconName);

        [DllImport("user32.dll")]
        private static extern bool DestroyIcon(IntPtr hIcon);

        [DllImport("user32.dll", CharSet = CharSet.Unicode)]
        private static extern IntPtr LoadImage(IntPtr hInst, string lpszName, uint uType, int cx, int cy, uint fuLoad);

        [DllImport("user32.dll")]
        private static extern IntPtr CallWindowProc(IntPtr lpPrevWndFunc, IntPtr hWnd, uint Msg, IntPtr wParam, IntPtr lParam);

        [DllImport("user32.dll", EntryPoint = "SetWindowLongPtrW")]
        private static extern IntPtr SetWindowLongPtr64(IntPtr hWnd, int nIndex, IntPtr dwNewLong);

        [DllImport("user32.dll", EntryPoint = "SetWindowLongW")]
        private static extern IntPtr SetWindowLong32(IntPtr hWnd, int nIndex, IntPtr dwNewLong);

        [DllImport("user32.dll")]
        private static extern IntPtr CreatePopupMenu();

        [DllImport("user32.dll", CharSet = CharSet.Unicode)]
        private static extern bool AppendMenu(IntPtr hMenu, uint uFlags, uint uIDNewItem, string lpNewItem);

        [DllImport("user32.dll")]
        private static extern bool DestroyMenu(IntPtr hMenu);

        [DllImport("user32.dll")]
        private static extern uint TrackPopupMenu(IntPtr hMenu, uint uFlags, int x, int y, int nReserved, IntPtr hWnd, IntPtr prcRect);

        [DllImport("user32.dll")]
        private static extern bool GetCursorPos(out POINT lpPoint);

        [DllImport("user32.dll")]
        private static extern bool SetForegroundWindow(IntPtr hWnd);

        private static IntPtr SetWindowLongPtr(IntPtr hWnd, int nIndex, IntPtr dwNewLong)
        {
            return IntPtr.Size == 8
                ? SetWindowLongPtr64(hWnd, nIndex, dwNewLong)
                : SetWindowLong32(hWnd, nIndex, dwNewLong);
        }
    }
}