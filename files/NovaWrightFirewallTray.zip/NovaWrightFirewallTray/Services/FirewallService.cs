﻿using NovaWrightFirewallTray.Models;
using System.Diagnostics;

namespace NovaWrightFirewallTray.Services
{
    public class FirewallService
    {
        private const int DomainProfile = 1;
        private const int PrivateProfile = 2;
        private const int PublicProfile = 4;

        private dynamic? _fwPolicy;
        private FirewallProfileState? _savedState;
        private FirewallProfileState? _lastObservedState;
        private DateTime _ignoreExternalUntil = DateTime.MinValue;

        public FirewallService()
        {
            try
            {
                Type type = Type.GetTypeFromProgID("HNetCfg.FwPolicy2")
                    ?? throw new InvalidOperationException("Could not get HNetCfg.FwPolicy2 type.");
                _fwPolicy = Activator.CreateInstance(type);
            }
            catch
            {
                // Reading may still work later; writing will go through the helper
                _fwPolicy = null;
            }
        }       

        public void NoteLocalChange()
        {
            // Ignore external-detection briefly after we change something
            _ignoreExternalUntil = DateTime.Now.AddSeconds(3);
            _lastObservedState = GetCurrentState();
        }

        public FirewallProfileState? CheckForExternalChange()
        {
            if (DateTime.Now < _ignoreExternalUntil)
                return null;

            var current = GetCurrentState();

            if (_lastObservedState is null)
            {
                _lastObservedState = current;
                return null;
            }

            if (_lastObservedState.Domain == current.Domain &&
                _lastObservedState.Private == current.Private &&
                _lastObservedState.Public == current.Public)
            {
                return null;
            }

            var previous = _lastObservedState;
            _lastObservedState = current;
            return previous; // caller logs previous → current
        }

        public FirewallProfileState GetCurrentState()
        {
            // Prefer direct COM read (usually works without elevation)
            if (_fwPolicy != null)
            {
                try
                {
                    return new FirewallProfileState
                    {
                        Domain = (bool)_fwPolicy.FirewallEnabled[DomainProfile],
                        Private = (bool)_fwPolicy.FirewallEnabled[PrivateProfile],
                        Public = (bool)_fwPolicy.FirewallEnabled[PublicProfile],
                        CapturedAt = DateTime.Now
                    };
                }
                catch { /* fall through to helper */ }
            }

            // Fallback: ask the helper
            return GetStateFromHelper();
        }

        public void SavePreDisableState()
        {
            _savedState = GetCurrentState();
        }

        public FirewallProfileState? GetSavedState() => _savedState;

        public async Task DisableProfilesAsync(bool domain = true, bool @private = true, bool @public = true)
        {
            // For now we always disable all three (we can refine later)
            await RunHelperAsync("disable");
            NoteLocalChange();
        }

        public async Task RestorePreviousStateAsync()
        {
            if (_savedState is null)
            {
                await ForceEnableAllAsync();
                NoteLocalChange();
                return;
            }

            // Pass the exact previous state to the helper
            string stateArg = $"{(_savedState.Domain ? 1 : 0)},{(_savedState.Private ? 1 : 0)},{(_savedState.Public ? 1 : 0)}";
            await RunHelperAsync("restore", stateArg);
            NoteLocalChange();
        }

        public async Task ForceEnableAllAsync()
        {
            await RunHelperAsync("forceenable");
            NoteLocalChange();
        }

        private async Task RunHelperAsync(string command, string? extraArg = null)
        {
            string helperPath = FindHelperPath();
            string arguments = string.IsNullOrEmpty(extraArg) ? command : $"{command} {extraArg}";

            Debug.WriteLine($"=== Launching helper ===");
            Debug.WriteLine($"Path: {helperPath}");
            Debug.WriteLine($"Arguments: {arguments}");

            var psi = new ProcessStartInfo
            {
                FileName = helperPath,
                Arguments = arguments,
                UseShellExecute = true,
                Verb = "runas",
                WindowStyle = ProcessWindowStyle.Hidden,
                CreateNoWindow = true
            };

            using var process = Process.Start(psi)
                ?? throw new InvalidOperationException("Failed to start firewall helper.");

            await process.WaitForExitAsync();

            Debug.WriteLine($"Helper exited with code: {process.ExitCode}");

            if (process.ExitCode != 0)
            {
                throw new InvalidOperationException($"Firewall helper failed with exit code {process.ExitCode}");
            }
        }

        public async Task SetProfilesAsync(bool domain, bool @private, bool @public)
        {
            string arg = $"{(domain ? 1 : 0)},{(@private ? 1 : 0)},{(@public ? 1 : 0)}";
            await RunHelperAsync("set", arg);
            NoteLocalChange();
        }

        // ─────────────────────────────────────────────
        // Helper process
        // ─────────────────────────────────────────────

        private FirewallProfileState GetStateFromHelper()
        {
            string helperPath = FindHelperPath();

            var psi = new ProcessStartInfo
            {
                FileName = helperPath,
                Arguments = "getstate",
                UseShellExecute = false,
                RedirectStandardOutput = true,
                CreateNoWindow = true
            };

            using var process = Process.Start(psi)
                ?? throw new InvalidOperationException("Failed to start firewall helper.");

            string output = process.StandardOutput.ReadToEnd();
            process.WaitForExit();

            // Expected format: Domain=1;Private=1;Public=1
            var parts = output.Split(';', StringSplitOptions.RemoveEmptyEntries);
            bool domain = false, priv = false, pub = false;

            foreach (var part in parts)
            {
                var kv = part.Split('=');
                if (kv.Length != 2) continue;

                bool value = kv[1].Trim() == "1";
                switch (kv[0].Trim())
                {
                    case "Domain": domain = value; break;
                    case "Private": priv = value; break;
                    case "Public": pub = value; break;
                }
            }

            return new FirewallProfileState
            {
                Domain = domain,
                Private = priv,
                Public = pub,
                CapturedAt = DateTime.Now
            };
        }


        private string FindHelperPath()
        {
            string baseDir = AppContext.BaseDirectory;
            Debug.WriteLine("=== Looking for helper ===");
            Debug.WriteLine("BaseDirectory: " + baseDir);

            string[] candidates =
            {
        // 1. Self-contained build (the one we want)
        @"C:\Dev\NovaWrightFirewallTray\NovaWrightFirewallHelper\bin\Debug\net8.0\win-x64\NovaWrightFirewallHelper.exe",

        // 2. Relative paths that should work after a proper copy
        Path.Combine(baseDir, "NovaWrightFirewallHelper.exe"),
        Path.Combine(baseDir, "..", "NovaWrightFirewallHelper.exe"),
        Path.Combine(baseDir, "..", "..", "NovaWrightFirewallHelper.exe"),

        // 3. Other common development locations
        Path.Combine(baseDir, "..", "..", "..", "..", "NovaWrightFirewallHelper", "bin", "Debug", "net8.0", "win-x64", "NovaWrightFirewallHelper.exe"),
        Path.Combine(baseDir, "..", "..", "..", "..", "..", "NovaWrightFirewallHelper", "bin", "Debug", "net8.0", "win-x64", "NovaWrightFirewallHelper.exe"),
    };

            foreach (var path in candidates)
            {
                try
                {
                    string full = Path.GetFullPath(path);
                    bool exists = File.Exists(full);
                    Debug.WriteLine($"Checking: {full}  →  {(exists ? "FOUND" : "missing")}");
                    if (exists)
                        return full;
                }
                catch (Exception ex)
                {
                    Debug.WriteLine($"Invalid path: {path}  ({ex.Message})");
                }
            }

            throw new FileNotFoundException("Could not find NovaWrightFirewallHelper.exe");
        }

        public sealed class FirewallRuleStats
        {
            public int Total { get; init; }
            public int Enabled { get; init; }
            public int Disabled { get; init; }
            public int Inbound { get; init; }
            public int Outbound { get; init; }
        }

        public FirewallRuleStats GetRuleStats()
        {
            int total = 0, enabled = 0, disabled = 0, inbound = 0, outbound = 0;

            try
            {
                dynamic policy = _fwPolicy;
                if (policy is null)
                {
                    Type type = Type.GetTypeFromProgID("HNetCfg.FwPolicy2")
                        ?? throw new InvalidOperationException("FwPolicy2 unavailable");
                    policy = Activator.CreateInstance(type)
                        ?? throw new InvalidOperationException("FwPolicy2 create failed");
                }

                dynamic rules = policy.Rules;
                foreach (dynamic rule in rules)
                {
                    total++;

                    try
                    {
                        if ((bool)rule.Enabled) enabled++;
                        else disabled++;
                    }
                    catch { }

                    try
                    {
                        // NET_FW_RULE_DIR_IN = 1, NET_FW_RULE_DIR_OUT = 2
                        int dir = (int)rule.Direction;
                        if (dir == 1) inbound++;
                        else if (dir == 2) outbound++;
                    }
                    catch { }
                }
            }
            catch (Exception ex)
            {
                Debug.WriteLine("GetRuleStats failed: " + ex.Message);
            }

            return new FirewallRuleStats
            {
                Total = total,
                Enabled = enabled,
                Disabled = disabled,
                Inbound = inbound,
                Outbound = outbound
            };
        }
    }
}
