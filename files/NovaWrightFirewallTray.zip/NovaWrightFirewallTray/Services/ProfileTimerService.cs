﻿using Microsoft.UI.Dispatching;

namespace NovaWrightFirewallTray.Services
{
    public enum FirewallProfileKind { Domain, Private, Public }

    public class ProfileTimerService
    {
        private readonly DispatcherQueueTimer _timer;
        private readonly DateTime?[] _endTimes = new DateTime?[3];
        private readonly bool?[] _savedEnabled = new bool?[3]; // previous state before disable

        public event EventHandler? Tick;
        public event EventHandler<FirewallProfileKind>? ProfileExpired;

        public ProfileTimerService()
        {
            _timer = DispatcherQueue.GetForCurrentThread().CreateTimer();
            _timer.Interval = TimeSpan.FromSeconds(1);
            _timer.Tick += (s, e) =>
            {
                for (int i = 0; i < 3; i++)
                {
                    if (_endTimes[i] is DateTime end && DateTime.Now >= end)
                    {
                        _endTimes[i] = null;
                        ProfileExpired?.Invoke(this, (FirewallProfileKind)i);
                    }
                }
                Tick?.Invoke(this, EventArgs.Empty);
            };
            _timer.Start();
        }

        public bool IsRunning(FirewallProfileKind profile) =>
            _endTimes[(int)profile].HasValue && Remaining(profile) > TimeSpan.Zero;

        public TimeSpan Remaining(FirewallProfileKind profile)
        {
            var end = _endTimes[(int)profile];
            if (end is null) return TimeSpan.Zero;
            var r = end.Value - DateTime.Now;
            return r < TimeSpan.Zero ? TimeSpan.Zero : r;
        }

        public bool? GetSavedEnabled(FirewallProfileKind profile) =>
            _savedEnabled[(int)profile];

        public void Start(FirewallProfileKind profile, bool previousEnabled, TimeSpan duration)
        {
            _savedEnabled[(int)profile] = previousEnabled;
            _endTimes[(int)profile] = DateTime.Now + duration;
        }

        public void Stop(FirewallProfileKind profile)
        {
            _endTimes[(int)profile] = null;
            // keep saved value until consumed on expire/manual on
        }

        public void ClearSaved(FirewallProfileKind profile) =>
            _savedEnabled[(int)profile] = null;
    }
}
