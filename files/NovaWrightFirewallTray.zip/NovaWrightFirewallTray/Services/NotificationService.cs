﻿using Microsoft.Windows.AppNotifications;
using Microsoft.Windows.AppNotifications.Builder;
using System.Diagnostics;

namespace NovaWrightFirewallTray.Services
{
    public class NotificationService
    {
        public bool EnableSound { get; set; } = true;

        public void ShowFirewallDisabled(int minutes)
        {
            ShowToast(
                "Windows Firewall Disabled",
                $"Firewall has been disabled. It will automatically re-enable in {minutes} minutes.");
        }

        public void ShowFirewallRestored()
        {
            ShowToast(
                "Windows Firewall Restored",
                "The firewall has been re-enabled and is protecting your system.");

            if (EnableSound)
                PlaySystemSound();
        }

        public void ShowWarning(string message)
        {
            ShowToast("Firewall Timer Warning", message);
        }

        private void ShowToast(string title, string message)
        {
            try
            {
                var notification = new AppNotificationBuilder()
                    .AddText(title)
                    .AddText(message)
                    .BuildNotification();

                AppNotificationManager.Default.Show(notification);
                Debug.WriteLine($"Toast shown, Id: {notification.Id}");
            }
            catch (Exception ex)
            {
                Debug.WriteLine($"Toast failed: {ex.GetType().Name} - {ex.Message}");
            }
        }

        public string CustomWavPath { get; set; } = "";

        private void PlaySystemSound()
        {
            try
            {
                if (!string.IsNullOrWhiteSpace(CustomWavPath) && System.IO.File.Exists(CustomWavPath))
                {
                    using var player = new System.Media.SoundPlayer(CustomWavPath);
                    player.Play();          // asynchronous
                }
                else
                {
                    System.Media.SystemSounds.Asterisk.Play();
                }
            }
            catch
            {
                // fallback
                try { System.Media.SystemSounds.Asterisk.Play(); } catch { }
            }
        }
    }
}