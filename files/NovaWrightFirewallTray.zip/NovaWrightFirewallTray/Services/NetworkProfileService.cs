﻿namespace NovaWrightFirewallTray.Services
{
    public enum NetworkCategory
    {
        Unknown = -1,
        Public = 0,
        Private = 1,
        Domain = 2
    }

    public class NetworkProfileService
    {
        // NetworkListManager CLSID
        private static readonly Guid CLSID_NetworkListManager =
            new Guid("DCB00C01-570F-4A9B-8D69-199FDBA5723B");

        public NetworkCategory GetActiveCategory()
        {
            try
            {
                Type? type = Type.GetTypeFromCLSID(CLSID_NetworkListManager);
                if (type is null)
                    return NetworkCategory.Unknown;

                dynamic nlm = Activator.CreateInstance(type)
                    ?? throw new InvalidOperationException("NLM create failed");

                // Connected networks
                dynamic connections = nlm.GetNetworkConnections();
                foreach (dynamic conn in connections)
                {
                    try
                    {
                        if (!conn.IsConnectedToInternet && !conn.IsConnected)
                            continue;

                        dynamic network = conn.GetNetwork();
                        // NLM_NETWORK_CATEGORY: Public=0, Private=1, DomainAuthenticated=2
                        int cat = (int)network.GetCategory();
                        return cat switch
                        {
                            0 => NetworkCategory.Public,
                            1 => NetworkCategory.Private,
                            2 => NetworkCategory.Domain,
                            _ => NetworkCategory.Unknown
                        };
                    }
                    catch
                    {
                        // try next connection
                    }
                }
            }
            catch
            {
                // ignore
            }

            return NetworkCategory.Unknown;
        }

        public string GetActiveCategoryDisplay()
        {
            return GetActiveCategory() switch
            {
                NetworkCategory.Domain => "Domain",
                NetworkCategory.Private => "Private",
                NetworkCategory.Public => "Public",
                _ => "Unknown"
            };
        }
    }
}
