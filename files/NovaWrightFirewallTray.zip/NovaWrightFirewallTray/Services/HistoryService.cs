﻿using NovaWrightFirewallTray.Models;
using System.Collections.ObjectModel;
using System.Text.Json;

namespace NovaWrightFirewallTray.Services
{
    public class HistoryService
    {
        private readonly string _historyPath;
        private const int MaxEntries = 200;

        public ObservableCollection<HistoryEntry> Entries { get; } = new();

        public HistoryService()
        {
            string folder = Path.Combine(
                Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),
                "NovaWrightFirewallTray");

            Directory.CreateDirectory(folder);
            _historyPath = Path.Combine(folder, "history.json");

            Load();
        }

        public void Add(string action, string details, string previousState, string newState)
        {
            var entry = new HistoryEntry
            {
                Timestamp = DateTime.Now,
                Action = action,
                Details = details,
                PreviousState = previousState,
                NewState = newState
            };

            Entries.Insert(0, entry);

            // Keep only the last MaxEntries
            while (Entries.Count > MaxEntries)
                Entries.RemoveAt(Entries.Count - 1);

            Save();
        }

        private void Save()
        {
            try
            {
                var options = new JsonSerializerOptions { WriteIndented = true };
                string json = JsonSerializer.Serialize(Entries.ToList(), options);
                File.WriteAllText(_historyPath, json);
            }
            catch { }
        }

        private void Load()
        {
            try
            {
                if (File.Exists(_historyPath))
                {
                    string json = File.ReadAllText(_historyPath);
                    var list = JsonSerializer.Deserialize<HistoryEntry[]>(json);
                    if (list != null)
                    {
                        foreach (var item in list)
                            Entries.Add(item);
                    }
                }
            }
            catch { }
        }
    }
}