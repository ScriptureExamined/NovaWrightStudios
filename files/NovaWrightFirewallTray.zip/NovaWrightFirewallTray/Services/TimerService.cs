﻿using Microsoft.UI.Dispatching;

namespace NovaWrightFirewallTray.Services
{
    public class TimerService
    {
        private readonly DispatcherQueueTimer _timer;
        private DateTime? _endTime;
        private TimeSpan _remainingWhenPaused;
        private bool _isPaused;
        private bool _hasWarned5Min;
        private bool _hasWarned1Min;
        private bool _hasWarned30Sec;

        public event EventHandler? Tick;
        public event EventHandler<int>? WarningReached;   // minutes remaining (5, 1, or 0 for 30sec)
        public event EventHandler? Expired;

        public bool IsRunning => _endTime.HasValue && !_isPaused && Remaining > TimeSpan.Zero;
        public bool IsPaused => _isPaused;
        public TimeSpan Remaining
        {
            get
            {
                if (_isPaused)
                    return _remainingWhenPaused;

                if (_endTime is null)
                    return TimeSpan.Zero;

                var remaining = _endTime.Value - DateTime.Now;
                return remaining > TimeSpan.Zero ? remaining : TimeSpan.Zero;
            }
        }

        public DateTime? EndTime => _endTime;

        public TimerService()
        {
            _timer = DispatcherQueue.GetForCurrentThread().CreateTimer();
            _timer.Interval = TimeSpan.FromSeconds(1);
            _timer.Tick += OnTimerTick;
        }

        /// <summary>
        /// Starts a new countdown for the given duration.
        /// </summary>
        public void Start(TimeSpan duration)
        {
            Stop(); // clear any previous timer

            _endTime = DateTime.Now.Add(duration);
            _isPaused = false;
            _remainingWhenPaused = TimeSpan.Zero;

            ResetWarnings();

            _timer.Start();
            Tick?.Invoke(this, EventArgs.Empty);
        }

        /// <summary>
        /// Starts a countdown that ends at a specific date/time ("Disable Until...").
        /// </summary>
        public void StartUntil(DateTime endTime)
        {
            if (endTime <= DateTime.Now)
                throw new ArgumentException("End time must be in the future.");

            Start(endTime - DateTime.Now);
        }

        public void Pause()
        {
            if (!IsRunning) return;

            _remainingWhenPaused = Remaining;
            _isPaused = true;
            _timer.Stop();
            Tick?.Invoke(this, EventArgs.Empty);
        }

        public void Resume()
        {
            if (!_isPaused || _remainingWhenPaused <= TimeSpan.Zero) return;

            _endTime = DateTime.Now.Add(_remainingWhenPaused);
            _isPaused = false;
            _remainingWhenPaused = TimeSpan.Zero;

            // Re-evaluate warnings based on new remaining time
            ResetWarningsBasedOnRemaining();

            _timer.Start();
            Tick?.Invoke(this, EventArgs.Empty);
        }

        public void AddMinutes(int minutes)
        {
            if (_endTime is null) return;

            if (_isPaused)
            {
                _remainingWhenPaused = _remainingWhenPaused.Add(TimeSpan.FromMinutes(minutes));
                if (_remainingWhenPaused < TimeSpan.Zero)
                    _remainingWhenPaused = TimeSpan.Zero;
            }
            else
            {
                _endTime = _endTime.Value.AddMinutes(minutes);
            }

            ResetWarningsBasedOnRemaining();
            Tick?.Invoke(this, EventArgs.Empty);
        }

        public void SubtractMinutes(int minutes) => AddMinutes(-minutes);

        public void Stop()
        {
            _timer.Stop();
            _endTime = null;
            _isPaused = false;
            _remainingWhenPaused = TimeSpan.Zero;
            ResetWarnings();
            Tick?.Invoke(this, EventArgs.Empty);
        }

        // ─────────────────────────────────────────────
        // Private helpers
        // ─────────────────────────────────────────────

        private void OnTimerTick(DispatcherQueueTimer sender, object args)
        {
            var remaining = Remaining;

            if (remaining <= TimeSpan.Zero)
            {
                _timer.Stop();
                _endTime = null;
                Expired?.Invoke(this, EventArgs.Empty);
                return;
            }

            // Multi-level warnings
            if (!_hasWarned5Min && remaining <= TimeSpan.FromMinutes(5) && remaining > TimeSpan.FromMinutes(1))
            {
                _hasWarned5Min = true;
                WarningReached?.Invoke(this, 5);
            }
            else if (!_hasWarned1Min && remaining <= TimeSpan.FromMinutes(1) && remaining > TimeSpan.FromSeconds(30))
            {
                _hasWarned1Min = true;
                WarningReached?.Invoke(this, 1);
            }
            else if (!_hasWarned30Sec && remaining <= TimeSpan.FromSeconds(30))
            {
                _hasWarned30Sec = true;
                WarningReached?.Invoke(this, 0); // 0 = 30 seconds
            }

            Tick?.Invoke(this, EventArgs.Empty);
        }

        private void ResetWarnings()
        {
            _hasWarned5Min = false;
            _hasWarned1Min = false;
            _hasWarned30Sec = false;
        }

        private void ResetWarningsBasedOnRemaining()
        {
            var remaining = Remaining;

            _hasWarned5Min = remaining <= TimeSpan.FromMinutes(5);
            _hasWarned1Min = remaining <= TimeSpan.FromMinutes(1);
            _hasWarned30Sec = remaining <= TimeSpan.FromSeconds(30);
        }
    }
}
