﻿using NovaWrightFirewallTray.Models;
using System.Text.Json;
using Windows.ApplicationModel;

namespace NovaWrightFirewallTray.Services
{
    public class SettingsService
    {
        private readonly string _settingsPath;
        private AppSettings _settings;

        public AppSettings Settings => _settings;

        public SettingsService()
        {
            string folder = Path.Combine(
                Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),
                "NovaWrightFirewallTray");

            Directory.CreateDirectory(folder);
            _settingsPath = Path.Combine(folder, "settings.json");

            _settings = Load();
        }

        public void Save()
        {
            var options = new JsonSerializerOptions { WriteIndented = true };
            string json = JsonSerializer.Serialize(_settings, options);
            File.WriteAllText(_settingsPath, json);
        }

        private AppSettings Load()
        {
            try
            {
                if (File.Exists(_settingsPath))
                {
                    string json = File.ReadAllText(_settingsPath);
                    return JsonSerializer.Deserialize<AppSettings>(json) ?? new AppSettings();
                }
            }
            catch
            {
                // Ignore and use defaults
            }

            return new AppSettings();
        }

        public void RememberDuration(int minutes)
        {
            if (minutes < 1) minutes = 1;
            if (minutes > 1440) minutes = 1440;

            App.SettingsService.Settings.LastUsedDisableMinutes = minutes;
            // Optional: also keep Default in sync — only if you want that behavior:
            // SettingsService.Settings.DefaultDisableMinutes = minutes;
            App.SettingsService.Save();
        }

        public static class StartupService
        {
            private const string TaskId = "NovaWrightFirewallTrayStartup";

            public static async Task<bool> IsEnabledAsync()
            {
                try
                {
                    var task = await StartupTask.GetAsync(TaskId);
                    return task.State == StartupTaskState.Enabled || task.State == StartupTaskState.EnabledByPolicy;
                }
                catch
                {
                    return false;
                }
            }

            public static async Task<bool> SetEnabledAsync(bool enable)
            {
                try
                {
                    var task = await StartupTask.GetAsync(TaskId);

                    if (enable)
                    {
                        var state = await task.RequestEnableAsync();
                        return state == StartupTaskState.Enabled || state == StartupTaskState.EnabledByPolicy;
                    }
                    else
                    {
                        task.Disable();
                        return true;
                    }
                }
                catch
                {
                    return false;
                }
            }
        }
    }
}
