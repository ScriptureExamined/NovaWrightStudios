﻿using Microsoft.UI.Xaml;

namespace NovaWrightFirewallTray
{
    public sealed partial class HelpWindow : Window
    {
        public HelpWindow()
        {
            this.InitializeComponent();
            HelpBody.Text = HelpText.Tutorial;
        }

        private void Close_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }
    }

    public static class HelpText
    {
        public const string Tutorial =
 @"NovaWright Firewall Monitor — Quick Start Guide
=============================================

WHAT THIS APP DOES
NovaWright Firewall Monitor lets you temporarily turn Windows Firewall off
(and back on) when you need it—for example while testing software, gaming,
or troubleshooting a network issue.

You can control it from:
• The system tray icon (bottom-right of the taskbar)
• The main window
• The keyboard shortcut Ctrl+Shift+F

IMPORTANT: Turning the firewall off reduces protection. Only do it when you
intentionally need to, and let the timer re-enable it when you’re done.


SYSTEM TRAY ICON
• Left-click the icon
  – Firewall fully on  → turns it off for the default time in Settings
  – Firewall fully off  → turns all profiles back on
  – Partially off       → asks what you want to do

• Hover over the icon to see the current status and any countdown timer.

• Right-click the icon for the full menu:
  – Disable for 5 / 15 / 30 / 60 minutes
  – Custom duration…
  – Disable until… (choose a date and time)
  – Add / Subtract 5 minutes
  – Pause / Resume timer
  – Restore Firewall (Emergency)
  – Open Main Window, Settings, Diagnostics, Help, About, Exit


MAIN WINDOW
The three cards (Domain, Private, Public) show whether each firewall profile
is On or Off.

• “Turn off” under a card turns only that profile off and starts a timer
  (using the default duration from Settings).
• “Turn on” turns that profile back on immediately.

Buttons at the bottom:
• Disable (Default)     – turns all profiles off for the default time
• Disable until…        – choose a date and time when the firewall should
                          turn back on
• Custom duration       – enter any number of minutes
• Restore               – returns the firewall to the state it had before
                          the last disable
• Emergency Enable      – forces all profiles on right away
• Settings / Diagnostics / Help / About


TIMERS
• Full disable (from tray or main window) uses one main timer.
  When it ends, the previous firewall state is restored.
• Turning a single profile off uses its own timer.
• You can Add/Subtract 5 minutes or Pause/Resume from the tray menu.


SETTINGS
• Default disable duration (used by left-click and “Disable (Default)”)
• Sound when the firewall is restored (optional custom WAV file)
• Warning notifications at 5 min, 1 min, and 30 seconds
• Confirmation before long disables
• Start with Windows (when allowed by the system)


SAFETY TIPS
• On a Public network, turning the Public profile off is especially risky—
  the app will warn you.
• Changes made in Windows Security will appear in History as “ExternalChange”
  and you’ll get a notification.
• Closing the main window can leave the app running in the tray.
  Use Exit (or “exit completely”) when you want to quit fully.


KEYBOARD SHORTCUT
Ctrl+Shift+F does the same thing as left-clicking the tray icon.


NEED MORE DETAIL?
• Diagnostics shows live status, active network type, rule counts, and history.
• About shows the version number.";
    }
}