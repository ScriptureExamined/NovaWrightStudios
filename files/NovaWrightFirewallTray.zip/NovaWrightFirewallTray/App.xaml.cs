﻿using Microsoft.UI.Dispatching;
using Microsoft.UI.Xaml;
using Microsoft.UI.Xaml.Controls;
using NovaWrightFirewallTray.Services;
using System.Diagnostics;
using System.Runtime.InteropServices;

namespace NovaWrightFirewallTray
{
    public partial class App : Application
    {
        private Window? _mainWindow;
        private TrayService? _trayService;
        private HotkeyService? _hotkeyService;
        private DispatcherQueueTimer? _externalTimer;
        private static Mutex? _singleInstanceMutex;
        private const string MutexName = "NovaWrightFirewallTray_SingleInstance";

        public static FirewallService FirewallService { get; private set; } = null!;
        public static TimerService TimerService { get; private set; } = null!;
        public static NotificationService NotificationService { get; private set; } = null!;
        public static SettingsService SettingsService { get; private set; } = null!;
        public static HistoryService HistoryService { get; private set; } = null!;
        public static ProfileTimerService ProfileTimerService { get; private set; } = null!;
        public static NetworkProfileService NetworkProfileService { get; private set; } = null!;

        public void RefreshTrayTooltip() => UpdateTrayTooltip();

        public App()
        {
            this.InitializeComponent();
        }

        protected override void OnLaunched(LaunchActivatedEventArgs args)
        {
            bool createdNew;
            _singleInstanceMutex = new Mutex(true, @"Global\NovaWrightFirewallTray_SingleInstance", out createdNew);

            if (!createdNew)
            {
                try { NativeMethods.ShowExistingInstance(); } catch { }
                try { _singleInstanceMutex?.Dispose(); } catch { }
                _singleInstanceMutex = null;
                Exit();
                return;   // must return — do not continue
            }

            // ... everything else unchanged ...

            // ── Services (create each only once) ──────────────────────────
            FirewallService = new FirewallService();
            TimerService = new TimerService();
            NotificationService = new NotificationService();
            SettingsService = new SettingsService();
            HistoryService = new HistoryService();
            ProfileTimerService = new ProfileTimerService();
            NetworkProfileService = new NetworkProfileService();

            NotificationService.CustomWavPath = SettingsService.Settings.CustomWavPath;
            NotificationService.EnableSound = SettingsService.Settings.EnableSounds;

            // Seed firewall observation so the first external poll has a baseline
            FirewallService.NoteLocalChange();

            try
            {
                Microsoft.Windows.AppNotifications.AppNotificationManager.Default.Register();
            }
            catch (Exception ex)
            {
                System.Diagnostics.Debug.WriteLine("Notification register failed: " + ex.Message);
            }

            // ── Main window ───────────────────────────────────────────────
            _mainWindow = new MainWindow();
            _mainWindow.AppWindow.SetIcon("Assets/Firewall.ico");

            // Global (all-profiles) timer → tooltip
            TimerService.Tick += (s, e) => UpdateTrayTooltip();
            TimerService.Expired += OnTimerExpired;
            TimerService.WarningReached += OnTimerWarning;

            // Per-profile timers → tooltip + auto-restore one profile
            ProfileTimerService.Tick += (s, e) => UpdateTrayTooltip();
            ProfileTimerService.ProfileExpired += OnProfileTimerExpired;

            _mainWindow.Activate();

            // ── Tray ──────────────────────────────────────────────────────
            _trayService = new TrayService(FirewallService, TimerService, SettingsService);
            _trayService.Initialize(_mainWindow);

            _trayService.LeftClicked += (s, e) => ToggleFirewall();

            _trayService.HelpRequested += (s, e) => new HelpWindow().Activate();
            _trayService.AboutRequested += (s, e) => new AboutWindow().Activate();

            _trayService.DisableRequested += async (s, minutes) =>
            {
                try
                {
                    if (!await ConfirmLongDurationIfNeededAsync(minutes))
                        return;

                    var previous = FirewallService.GetCurrentState().ToString();
                    FirewallService.SavePreDisableState();
                    await FirewallService.DisableProfilesAsync();
                    TimerService.Start(TimeSpan.FromMinutes(minutes));
                    RememberDuration(minutes);
                    HistoryService.Add("Disable", $"Tray menu – {minutes} min", previous, FirewallService.GetCurrentState().ToString());
                    NotificationService.ShowFirewallDisabled(minutes);
                    UpdateTrayTooltip();
                }
                catch (Exception ex)
                {
                    Debug.WriteLine(ex.Message);
                }
            };

            _trayService.CustomDurationRequested += async (s, e) => await RunCustomDurationAsync();
            _trayService.DisableUntilRequested += async (s, e) => await RunDisableUntilAsync();

            _trayService.Add5Requested += (s, e) =>
            {
                TimerService.AddMinutes(5);
                UpdateTrayTooltip();
            };

            _trayService.Subtract5Requested += (s, e) =>
            {
                TimerService.SubtractMinutes(5);
                UpdateTrayTooltip();
            };

            _trayService.EmergencyRestoreRequested += async (s, e) =>
            {
                try
                {
                    var previous = FirewallService.GetCurrentState().ToString();
                    TimerService.Stop();
                    await FirewallService.ForceEnableAllAsync();
                    HistoryService.Add("ForceEnable", "Tray Emergency", previous, FirewallService.GetCurrentState().ToString());
                    NotificationService.ShowFirewallRestored();
                    UpdateTrayTooltip();
                }
                catch (Exception ex)
                {
                    Debug.WriteLine(ex.Message);
                }
            };

            _trayService.OpenMainWindowRequested += (s, e) =>
            {
                _mainWindow?.AppWindow.Show();
                _mainWindow?.Activate();
            };

            _trayService.OpenSettingsRequested += (s, e) =>
            {
                var win = new SettingsWindow(SettingsService);
                win.Activate();
            };

            _trayService.OpenDiagnosticsRequested += (s, e) =>
            {
                var win = new DiagnosticsWindow();
                win.Activate();
            };

            _trayService.ExitRequested += (s, e) =>
            {
                ShutdownApp();
            };            

            // ── Hotkey (after window has a HWND) ──────────────────────────
            _mainWindow.Activated += (s, e) =>
            {
                if (_hotkeyService == null)
                {
                    _hotkeyService = new HotkeyService();
                    _hotkeyService.Register(_mainWindow);
                    _hotkeyService.HotkeyPressed += (sender, args) => ToggleFirewall();
                }
            };

            // ── External change detection (keep timer in a field) ─────────
            _externalTimer = _mainWindow.DispatcherQueue.CreateTimer();
            _externalTimer.Interval = TimeSpan.FromSeconds(5);
            _externalTimer.Tick += (s, e) =>
            {
                try
                {
                    var previous = FirewallService.CheckForExternalChange();
                    if (previous is null)
                        return;

                    var current = FirewallService.GetCurrentState();

                    HistoryService.Add(
                        "ExternalChange",
                        "Changed outside NovaWright (e.g. Windows Security)",
                        previous.ToString(),
                        current.ToString());

                    NotificationService.ShowWarning(
                        $"External firewall change detected.\n{previous} → {current}");

                    UpdateTrayTooltip();
                    Debug.WriteLine($"EXTERNAL: {previous} → {current}");
                }
                catch (Exception ex)
                {
                    Debug.WriteLine("External check failed: " + ex.Message);
                }
            };
            _externalTimer.Start();

            UpdateTrayTooltip();
        }

        /// <summary>Full exit — call this from tray Exit and "exit completely".</summary>
        public void ShutdownApp()
        {
            try { _externalTimer?.Stop(); } catch { }
            try { _trayService?.Dispose(); } catch { }
            try { _hotkeyService?.Dispose(); } catch { }

            try
            {
                _singleInstanceMutex?.ReleaseMutex();
            }
            catch { /* not owned or already released */ }

            try { _singleInstanceMutex?.Dispose(); } catch { }
            _singleInstanceMutex = null;

            // Hard kill so the process really disappears (including under the VS debugger)
            Environment.Exit(0);
        }

        public void RememberDuration(int minutes)
        {
            if (minutes < 1) minutes = 1;
            if (minutes > 1440) minutes = 1440;

            SettingsService.Settings.LastUsedDisableMinutes = minutes;
            SettingsService.Save();
        }

        private async void OnProfileTimerExpired(object? sender, FirewallProfileKind profile)
        {
            try
            {
                var saved = ProfileTimerService.GetSavedEnabled(profile);
                var state = FirewallService.GetCurrentState();

                bool d = state.Domain, p = state.Private, u = state.Public;
                bool restoreTo = saved ?? true;

                switch (profile)
                {
                    case FirewallProfileKind.Domain: d = restoreTo; break;
                    case FirewallProfileKind.Private: p = restoreTo; break;
                    case FirewallProfileKind.Public: u = restoreTo; break;
                }

                await FirewallService.SetProfilesAsync(d, p, u);
                ProfileTimerService.ClearSaved(profile);

                HistoryService.Add(
                    "AutoRestore",
                    $"{profile} timer expired → {(restoreTo ? "On" : "Off")}",
                    state.ToString(),
                    FirewallService.GetCurrentState().ToString());

                NotificationService.ShowFirewallRestored();
                UpdateTrayTooltip();
            }
            catch (Exception ex)
            {
                Debug.WriteLine(ex.Message);
            }
        }

        public async Task RunCustomDurationAsync()
        {
            try
            {
                if (_mainWindow?.Content?.XamlRoot == null)
                    return;

                _mainWindow.AppWindow.Show();
                _mainWindow.Activate();

                var numberBox = new NumberBox
                {
                    Header = "Minutes",
                    Minimum = 1,
                    Maximum = 1440,
                    Value = SettingsService.Settings.LastUsedDisableMinutes > 0
        ? SettingsService.Settings.LastUsedDisableMinutes
        : SettingsService.Settings.DefaultDisableMinutes,
                    SpinButtonPlacementMode = NumberBoxSpinButtonPlacementMode.Inline
                };

                var dialog = new ContentDialog
                {
                    Title = "Custom disable duration",
                    Content = numberBox,
                    PrimaryButtonText = "Disable",
                    CloseButtonText = "Cancel",
                    DefaultButton = ContentDialogButton.Primary,
                    XamlRoot = _mainWindow.Content.XamlRoot
                };

                var result = await dialog.ShowAsync();
                if (result != ContentDialogResult.Primary)
                    return;

                int minutes = (int)Math.Max(1, Math.Min(1440, numberBox.Value));
                if (!await ConfirmLongDurationIfNeededAsync(minutes))
                    return;

                var previous = FirewallService.GetCurrentState().ToString();
                FirewallService.SavePreDisableState();
                await FirewallService.DisableProfilesAsync();
                TimerService.Start(TimeSpan.FromMinutes(minutes));
                RememberDuration(minutes);
                HistoryService.Add("Disable", $"Custom duration – {minutes} min", previous, FirewallService.GetCurrentState().ToString());
                NotificationService.ShowFirewallDisabled(minutes);
                UpdateTrayTooltip();
            }
            catch (Exception ex)
            {
                Debug.WriteLine(ex.Message);
            }
        }

        public async Task RunDisableUntilAsync()
        {
            try
            {
                if (_mainWindow?.Content?.XamlRoot == null)
                    return;

                _mainWindow.AppWindow.Show();
                _mainWindow.Activate();

                var datePicker = new CalendarDatePicker
                {
                    Header = "Date",
                    Date = DateTimeOffset.Now.Date,
                    MinDate = DateTimeOffset.Now.Date,
                    MaxDate = DateTimeOffset.Now.Date.AddDays(7)   // safety cap, increase to add more days to the calendar
                };

                var timePicker = new TimePicker
                {
                    Header = "Time",
                    ClockIdentifier = "12HourClock",
                    SelectedTime = DateTime.Now.AddHours(1).TimeOfDay
                };

                var panel = new StackPanel { Spacing = 16 };
                panel.Children.Add(datePicker);
                panel.Children.Add(timePicker);

                var dialog = new ContentDialog
                {
                    Title = "Disable until…",
                    Content = panel,
                    PrimaryButtonText = "Disable",
                    CloseButtonText = "Cancel",
                    DefaultButton = ContentDialogButton.Primary,
                    XamlRoot = _mainWindow.Content.XamlRoot
                };

                var result = await dialog.ShowAsync();
                if (result != ContentDialogResult.Primary)
                    return;

                if (datePicker.Date is null || timePicker.SelectedTime is null)
                    return;

                var now = DateTime.Now;
                var target = datePicker.Date.Value.DateTime.Date + timePicker.SelectedTime.Value;

                // If the chosen date+time is already in the past, move it to tomorrow
                if (target <= now)
                    target = target.AddDays(1);

                var minutes = (int)Math.Ceiling((target - now).TotalMinutes);
                if (minutes < 1) minutes = 1;
                if (minutes > 7 * 24 * 60) minutes = 7 * 24 * 60;   // match the 7-day cap

                if (!await ConfirmLongDurationIfNeededAsync(minutes))
                    return;

                var previous = FirewallService.GetCurrentState().ToString();
                FirewallService.SavePreDisableState();
                await FirewallService.DisableProfilesAsync();
                TimerService.Start(TimeSpan.FromMinutes(minutes));
                RememberDuration(minutes);
                HistoryService.Add(
                    "Disable",
                    $"Disable until {target:g} ({minutes} min)",
                    previous,
                    FirewallService.GetCurrentState().ToString());
                NotificationService.ShowFirewallDisabled(minutes);
                UpdateTrayTooltip();
            }
            catch (Exception ex)
            {
                Debug.WriteLine(ex.Message);
            }
        }        

        private async void ToggleFirewall()
        {
            try
            {
                var state = FirewallService.GetCurrentState();
                var previous = state.ToString();

                bool anyProfileTimer =
                    ProfileTimerService.IsRunning(FirewallProfileKind.Domain) ||
                    ProfileTimerService.IsRunning(FirewallProfileKind.Private) ||
                    ProfileTimerService.IsRunning(FirewallProfileKind.Public);

                bool globalTimer = TimerService.IsRunning || TimerService.IsPaused;
                bool partial = !state.IsFullyEnabled && (state.Domain || state.Private || state.Public);
                // partial = some on, some off (not all off, not all on)

                bool allOff = !state.Domain && !state.Private && !state.Public;

                // All off, or only timers → treat as "turn all on"
                if (allOff || (globalTimer && state.IsFullyEnabled == false && !partial))
                {
                    await EnableAllFromTrayAsync(previous);
                    return;
                }

                // Fully on → timed disable all
                if (state.IsFullyEnabled && !globalTimer && !anyProfileTimer)
                {
                    await DisableAllFromTrayAsync(previous);
                    return;
                }

                // Global timer running and fully disabled path already handled;
                // if global timer running, left-click restores (enable all)
                if (globalTimer)
                {
                    await EnableAllFromTrayAsync(previous);
                    return;
                }

                // Partial state → ask
                if (partial || anyProfileTimer)
                {
                    if (_mainWindow?.Content?.XamlRoot == null)
                    {
                        await EnableAllFromTrayAsync(previous); // safe default
                        return;
                    }

                    _mainWindow.AppWindow.Show();
                    _mainWindow.Activate();

                    var dialog = new ContentDialog
                    {
                        Title = "Firewall is partially disabled",
                        Content = "Some profiles are off. What do you want to do?",
                        PrimaryButtonText = "Turn all on",
                        SecondaryButtonText = "Turn all off",
                        CloseButtonText = "Cancel",
                        DefaultButton = ContentDialogButton.Primary,
                        XamlRoot = _mainWindow.Content.XamlRoot
                    };

                    var result = await dialog.ShowAsync();

                    if (result == ContentDialogResult.Primary)
                        await EnableAllFromTrayAsync(previous);
                    else if (result == ContentDialogResult.Secondary)
                        await DisableAllFromTrayAsync(previous);
                    // Cancel → do nothing

                    return;
                }

                // Fallback
                await DisableAllFromTrayAsync(previous);
            }
            catch (Exception ex)
            {
                Debug.WriteLine("Firewall operation failed: " + ex.Message);
            }
        }

        private async Task EnableAllFromTrayAsync(string previous)
        {
            TimerService.Stop();

            ProfileTimerService.Stop(FirewallProfileKind.Domain);
            ProfileTimerService.Stop(FirewallProfileKind.Private);
            ProfileTimerService.Stop(FirewallProfileKind.Public);
            ProfileTimerService.ClearSaved(FirewallProfileKind.Domain);
            ProfileTimerService.ClearSaved(FirewallProfileKind.Private);
            ProfileTimerService.ClearSaved(FirewallProfileKind.Public);

            await FirewallService.ForceEnableAllAsync();

            HistoryService.Add("Restore", "Tray / hotkey – enable all", previous, FirewallService.GetCurrentState().ToString());
            NotificationService.ShowFirewallRestored();
            UpdateTrayTooltip();
        }

        private async Task DisableAllFromTrayAsync(string previous)
        {
            int minutes = SettingsService.Settings.DefaultDisableMinutes;

            if (!await ConfirmLongDurationIfNeededAsync(minutes))
                return;

            // Clear per-profile timers; full disable takes over
            ProfileTimerService.Stop(FirewallProfileKind.Domain);
            ProfileTimerService.Stop(FirewallProfileKind.Private);
            ProfileTimerService.Stop(FirewallProfileKind.Public);
            ProfileTimerService.ClearSaved(FirewallProfileKind.Domain);
            ProfileTimerService.ClearSaved(FirewallProfileKind.Private);
            ProfileTimerService.ClearSaved(FirewallProfileKind.Public);

            FirewallService.SavePreDisableState();
            await FirewallService.DisableProfilesAsync();
            TimerService.Start(TimeSpan.FromMinutes(minutes));
            RememberDuration(minutes);

            HistoryService.Add("Disable", $"Tray / hotkey – {minutes} min", previous, FirewallService.GetCurrentState().ToString());
            NotificationService.ShowFirewallDisabled(minutes);
            UpdateTrayTooltip();
        }

        private async void OnTimerExpired(object? sender, EventArgs e)
        {
            try
            {
                var previous = FirewallService.GetCurrentState().ToString();
                await FirewallService.RestorePreviousStateAsync();
                HistoryService.Add("AutoRestore", "Timer expired", previous, FirewallService.GetCurrentState().ToString());
                NotificationService.ShowFirewallRestored();
                UpdateTrayTooltip();
            }
            catch (Exception ex)
            {
                Debug.WriteLine("Auto-restore failed: " + ex.Message);
            }
        }

        public async Task<bool> ConfirmLongDurationIfNeededAsync(int minutes)
        {
            var settings = SettingsService.Settings;

            if (!settings.ConfirmLongDurations)
                return true;
            if (minutes < settings.LongDurationThresholdMinutes)
                return true;
            if (_mainWindow?.Content?.XamlRoot == null)
                return true;

            var dialog = new ContentDialog
            {
                Title = "Confirm long disable",
                Content = $"You are about to disable the firewall for {minutes} minutes.\n\nContinue?",
                PrimaryButtonText = "Yes, disable",
                CloseButtonText = "Cancel",
                DefaultButton = ContentDialogButton.Close,
                XamlRoot = _mainWindow.Content.XamlRoot
            };

            _mainWindow.AppWindow.Show();
            _mainWindow.Activate();

            var result = await dialog.ShowAsync();
            return result == ContentDialogResult.Primary;
        }

        internal static class NativeMethods
        {
            private const string WindowTitle = "NovaWright Firewall Monitor"; // must match MainWindow Title

            [DllImport("user32.dll", CharSet = CharSet.Unicode)]
            private static extern IntPtr FindWindow(string? lpClassName, string lpWindowName);

            [DllImport("user32.dll")]
            private static extern bool ShowWindow(IntPtr hWnd, int nCmdShow);

            [DllImport("user32.dll")]
            private static extern bool SetForegroundWindow(IntPtr hWnd);

            private const int SW_RESTORE = 9;
            private const int SW_SHOW = 5;

            public static void ShowExistingInstance()
            {
                IntPtr hWnd = FindWindow(null, WindowTitle);
                if (hWnd != IntPtr.Zero)
                {
                    ShowWindow(hWnd, SW_RESTORE);
                    SetForegroundWindow(hWnd);
                }
            }
        }

        private void OnTimerWarning(object? sender, int minutes)
        {
            bool show = minutes switch
            {
                5 => SettingsService.Settings.Show5MinuteWarning,
                1 => SettingsService.Settings.Show1MinuteWarning,
                0 => SettingsService.Settings.Show30SecondWarning,
                _ => true
            };

            if (!show) return;

            string msg = minutes switch
            {
                5 => "5 minutes remaining until the firewall is re-enabled.",
                1 => "1 minute remaining until the firewall is re-enabled.",
                0 => "30 seconds remaining until the firewall is re-enabled.",
                _ => $"{minutes} minutes remaining."
            };

            NotificationService.ShowWarning(msg);
        }

        private void UpdateTrayTooltip()
        {
            _trayService?.UpdateTrayAppearance();
        }
    }
}
