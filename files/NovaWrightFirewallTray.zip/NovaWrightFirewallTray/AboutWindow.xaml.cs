﻿using Microsoft.UI.Xaml;
using Windows.ApplicationModel;

namespace NovaWrightFirewallTray
{
    public sealed partial class AboutWindow : Window
    {
        public AboutWindow()
        {
            this.InitializeComponent();
            VersionText.Text = "Version " + GetVersionString();
        }

        private static string GetVersionString()
        {
            try
            {
                var v = Package.Current.Id.Version;
                return $"{v.Major}.{v.Minor}.{v.Build}.{v.Revision}";
            }
            catch
            {
                var v = System.Reflection.Assembly.GetExecutingAssembly().GetName().Version;
                return v?.ToString() ?? "1.0.0";
            }
        }

        private void Close_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }
    }
}